from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

BASE_TEMP = tempfile.mkdtemp(prefix='erasekey_test_')
os.environ['ERASEKEY_DB_PATH'] = str(Path(BASE_TEMP) / 'test.db')
os.environ['ERASEKEY_ROOT_KEY_PATH'] = str(Path(BASE_TEMP) / '.root_kek')

from fastapi.testclient import TestClient

from app.db import init_db
from app.main import app


class EraseKeyFlowTests(unittest.TestCase):
    def setUp(self) -> None:
        db_path = Path(os.environ['ERASEKEY_DB_PATH'])
        if db_path.exists():
            db_path.unlink()
        init_db()
        self.client = TestClient(app)

    def test_end_to_end_cryptographic_erasure(self) -> None:
        tenant = self.client.post('/tenants', json={'name': 'Acme'}).json()
        dataset = self.client.post(
            '/datasets',
            json={
                'tenant_id': tenant['id'],
                'name': 'support_tickets',
                'description': 'Support cases',
            },
        ).json()
        record = self.client.post(
            '/records',
            json={
                'tenant_id': tenant['id'],
                'dataset_id': dataset['id'],
                'subject_id': 'user_123',
                'record_type': 'ticket',
                'payload': {'email': 'user@example.com', 'message': 'Please delete my account.'},
            },
        ).json()
        readable = self.client.get(f"/records/{record['id']}")
        self.assertEqual(readable.status_code, 200)
        self.assertEqual(readable.json()['erase_status'], 'readable')
        self.assertEqual(readable.json()['payload']['email'], 'user@example.com')

        deletion_request = self.client.post(
            '/deletion-requests',
            json={
                'tenant_id': tenant['id'],
                'dataset_id': dataset['id'],
                'subject_id': 'user_123',
                'requested_by': 'privacy-team',
                'reason': 'GDPR erasure request',
            },
        ).json()
        self.assertEqual(deletion_request['status'], 'pending')

        executed = self.client.post(f"/deletion-requests/{deletion_request['id']}/execute")
        self.assertEqual(executed.status_code, 200)
        self.assertEqual(executed.json()['status'], 'executed')

        erased = self.client.get(f"/records/{record['id']}")
        self.assertEqual(erased.status_code, 200)
        self.assertEqual(erased.json()['erase_status'], 'cryptographically_erased')
        self.assertIsNone(erased.json()['payload'])

        evidence = self.client.get(f"/deletion-requests/{deletion_request['id']}/evidence")
        self.assertEqual(evidence.status_code, 200)
        body = evidence.json()
        self.assertEqual(body['status'], 'executed')
        self.assertEqual(body['evidence']['record_count'], 1)
        self.assertEqual(body['evidence']['verification']['result'], 'unreadable')

    def test_legal_hold_blocks_then_release_allows_deletion(self) -> None:
        tenant = self.client.post('/tenants', json={'name': 'Acme'}).json()
        dataset = self.client.post(
            '/datasets',
            json={'tenant_id': tenant['id'], 'name': 'contracts'},
        ).json()
        hold = self.client.post(
            '/legal-holds',
            json={
                'tenant_id': tenant['id'],
                'dataset_id': dataset['id'],
                'subject_id': 'user_456',
                'reason': 'Pending litigation',
            },
        )
        self.assertEqual(hold.status_code, 201)

        deletion_request = self.client.post(
            '/deletion-requests',
            json={
                'tenant_id': tenant['id'],
                'dataset_id': dataset['id'],
                'subject_id': 'user_456',
                'requested_by': 'privacy-team',
                'reason': 'Customer request',
            },
        ).json()
        self.assertEqual(deletion_request['status'], 'blocked')

        blocked_execute = self.client.post(f"/deletion-requests/{deletion_request['id']}/execute")
        self.assertEqual(blocked_execute.status_code, 200)
        self.assertEqual(blocked_execute.json()['status'], 'blocked')

        released = self.client.post(f"/legal-holds/{hold.json()['id']}/release")
        self.assertEqual(released.status_code, 200)
        self.assertFalse(released.json()['active'])

        unblocked_execute = self.client.post(f"/deletion-requests/{deletion_request['id']}/execute")
        self.assertEqual(unblocked_execute.status_code, 200)
        self.assertEqual(unblocked_execute.json()['status'], 'executed')


if __name__ == '__main__':
    unittest.main()

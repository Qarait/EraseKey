from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DATA_DIR.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv('ERASEKEY_APP_NAME', 'EraseKey')
    database_path: str = os.getenv('ERASEKEY_DB_PATH', str(DATA_DIR / 'erasekey.db'))
    root_key_path: str = os.getenv('ERASEKEY_ROOT_KEY_PATH', str(DATA_DIR / '.demo_root_kek'))
    demo_mode: bool = os.getenv('ERASEKEY_DEMO_MODE', 'true').lower() in {'1', 'true', 'yes'}


settings = Settings()

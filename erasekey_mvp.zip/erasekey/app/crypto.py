from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .config import settings
from .utils import canonical_json

WRAP_AAD = b'erasekey.wrap.v1'


class CryptoError(Exception):
    """Raised when cryptographic operations fail."""


class LocalRootKeyProvider:
    """Demo-only root key provider.

    In production, this should be replaced with AWS KMS / CloudHSM / Vault backed key wrapping.
    """

    def __init__(self, key_path: str) -> None:
        self.key_path = Path(key_path)
        self.key_path.parent.mkdir(parents=True, exist_ok=True)

    def load_or_create(self) -> bytes:
        if self.key_path.exists():
            raw = self.key_path.read_bytes()
            if len(raw) != 32:
                raise CryptoError('Root key file exists but is not 32 bytes long.')
            return raw
        key = os.urandom(32)
        self.key_path.write_bytes(key)
        try:
            os.chmod(self.key_path, 0o600)
        except PermissionError:
            # Best effort on non-POSIX systems.
            pass
        return key


class EnvelopeCrypto:
    def __init__(self, root_key: bytes) -> None:
        if len(root_key) != 32:
            raise CryptoError('Root key must be 32 bytes for AES-256-GCM.')
        self._root_key = root_key
        self._root_aes = AESGCM(root_key)

    @classmethod
    def demo(cls) -> 'EnvelopeCrypto':
        provider = LocalRootKeyProvider(settings.root_key_path)
        return cls(provider.load_or_create())

    def generate_data_key(self) -> bytes:
        return os.urandom(32)

    def wrap_key(self, data_key: bytes) -> tuple[bytes, bytes]:
        nonce = os.urandom(12)
        wrapped = self._root_aes.encrypt(nonce, data_key, WRAP_AAD)
        return wrapped, nonce

    def unwrap_key(self, wrapped_key: bytes | None, wrapped_nonce: bytes | None) -> bytes:
        if not wrapped_key or not wrapped_nonce:
            raise CryptoError('Wrapped key material is missing or has been destroyed.')
        try:
            return self._root_aes.decrypt(wrapped_nonce, wrapped_key, WRAP_AAD)
        except Exception as exc:  # cryptography raises InvalidTag and friends
            raise CryptoError('Unable to unwrap data key.') from exc

    def encrypt_payload(self, data_key: bytes, payload: dict[str, Any], aad: dict[str, Any]) -> tuple[bytes, bytes]:
        nonce = os.urandom(12)
        aes = AESGCM(data_key)
        plaintext = canonical_json(payload).encode('utf-8')
        aad_bytes = canonical_json(aad).encode('utf-8')
        ciphertext = aes.encrypt(nonce, plaintext, aad_bytes)
        return ciphertext, nonce

    def decrypt_payload(self, data_key: bytes, ciphertext: bytes, nonce: bytes, aad: dict[str, Any]) -> dict[str, Any]:
        aes = AESGCM(data_key)
        aad_bytes = canonical_json(aad).encode('utf-8')
        try:
            plaintext = aes.decrypt(nonce, ciphertext, aad_bytes)
        except Exception as exc:
            raise CryptoError('Unable to decrypt record.') from exc
        import json

        return json.loads(plaintext.decode('utf-8'))

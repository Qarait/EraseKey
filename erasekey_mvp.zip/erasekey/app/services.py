from __future__ import annotations

import json
import sqlite3
from typing import Any

from fastapi import HTTPException, status

from .crypto import CryptoError, EnvelopeCrypto
from .db import get_conn
from .schemas import (
    DatasetCreate,
    DeletionRequestCreate,
    LegalHoldCreate,
    RecordCreate,
    TenantCreate,
)
from .utils import canonical_json, new_id, sha256_hex, utc_now

crypto = EnvelopeCrypto.demo()


def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {key: row[key] for key in row.keys()}


def _audit(conn: sqlite3.Connection, entity_type: str, entity_id: str, action: str, payload: dict[str, Any]) -> None:
    conn.execute(
        """
        INSERT INTO audit_events (id, entity_type, entity_id, action, payload_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            new_id('audit'),
            entity_type,
            entity_id,
            action,
            canonical_json(payload),
            utc_now(),
        ),
    )


def _fetch_tenant(conn: sqlite3.Connection, tenant_id: str) -> dict[str, Any]:
    row = conn.execute('SELECT * FROM tenants WHERE id = ?', (tenant_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail='Tenant not found.')
    return _row_to_dict(row) or {}


def _fetch_dataset(conn: sqlite3.Connection, dataset_id: str) -> dict[str, Any]:
    row = conn.execute('SELECT * FROM datasets WHERE id = ?', (dataset_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail='Dataset not found.')
    return _row_to_dict(row) or {}


def create_tenant(payload: TenantCreate) -> dict[str, Any]:
    record = {
        'id': new_id('tenant'),
        'name': payload.name.strip(),
        'created_at': utc_now(),
    }
    with get_conn() as conn:
        conn.execute(
            'INSERT INTO tenants (id, name, created_at) VALUES (?, ?, ?)',
            (record['id'], record['name'], record['created_at']),
        )
        _audit(conn, 'tenant', record['id'], 'tenant.created', record)
    return record


def list_tenants() -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute('SELECT * FROM tenants ORDER BY created_at DESC').fetchall()
        return [_row_to_dict(row) or {} for row in rows]


def create_dataset(payload: DatasetCreate) -> dict[str, Any]:
    with get_conn() as conn:
        _fetch_tenant(conn, payload.tenant_id)
        record = {
            'id': new_id('dataset'),
            'tenant_id': payload.tenant_id,
            'name': payload.name.strip(),
            'description': payload.description,
            'retention_days': payload.retention_days,
            'created_at': utc_now(),
        }
        try:
            conn.execute(
                'INSERT INTO datasets (id, tenant_id, name, description, retention_days, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (
                    record['id'],
                    record['tenant_id'],
                    record['name'],
                    record['description'],
                    record['retention_days'],
                    record['created_at'],
                ),
            )
        except sqlite3.IntegrityError as exc:
            raise HTTPException(status_code=409, detail='Dataset name already exists for this tenant.') from exc
        _audit(conn, 'dataset', record['id'], 'dataset.created', record)
    return record


def list_datasets(tenant_id: str | None = None) -> list[dict[str, Any]]:
    with get_conn() as conn:
        if tenant_id:
            rows = conn.execute(
                'SELECT * FROM datasets WHERE tenant_id = ? ORDER BY created_at DESC',
                (tenant_id,),
            ).fetchall()
        else:
            rows = conn.execute('SELECT * FROM datasets ORDER BY created_at DESC').fetchall()
        return [_row_to_dict(row) or {} for row in rows]


def _find_active_holds(
    conn: sqlite3.Connection,
    tenant_id: str,
    dataset_id: str,
    subject_id: str,
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT *
        FROM legal_holds
        WHERE tenant_id = ?
          AND active = 1
          AND (dataset_id IS NULL OR dataset_id = ?)
          AND (subject_id IS NULL OR subject_id = ?)
        ORDER BY created_at DESC
        """,
        (tenant_id, dataset_id, subject_id),
    ).fetchall()
    results: list[dict[str, Any]] = []
    for row in rows:
        item = _row_to_dict(row) or {}
        item['active'] = bool(item['active'])
        results.append(item)
    return results


def create_legal_hold(payload: LegalHoldCreate) -> dict[str, Any]:
    with get_conn() as conn:
        _fetch_tenant(conn, payload.tenant_id)
        if payload.dataset_id:
            dataset = _fetch_dataset(conn, payload.dataset_id)
            if dataset['tenant_id'] != payload.tenant_id:
                raise HTTPException(status_code=400, detail='Dataset does not belong to tenant.')
        record = {
            'id': new_id('hold'),
            'tenant_id': payload.tenant_id,
            'dataset_id': payload.dataset_id,
            'subject_id': payload.subject_id,
            'reason': payload.reason.strip(),
            'active': True,
            'created_at': utc_now(),
            'released_at': None,
        }
        conn.execute(
            """
            INSERT INTO legal_holds (id, tenant_id, dataset_id, subject_id, reason, active, created_at, released_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record['id'],
                record['tenant_id'],
                record['dataset_id'],
                record['subject_id'],
                record['reason'],
                1,
                record['created_at'],
                None,
            ),
        )
        _audit(conn, 'legal_hold', record['id'], 'legal_hold.created', record)
    return record


def release_legal_hold(hold_id: str) -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM legal_holds WHERE id = ?', (hold_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail='Legal hold not found.')
        item = _row_to_dict(row) or {}
        if not bool(item['active']):
            item['active'] = False
            return item
        released_at = utc_now()
        conn.execute(
            'UPDATE legal_holds SET active = 0, released_at = ? WHERE id = ?',
            (released_at, hold_id),
        )
        item['active'] = False
        item['released_at'] = released_at
        _audit(conn, 'legal_hold', hold_id, 'legal_hold.released', {'released_at': released_at})
        return item


def _next_subject_key_version(conn: sqlite3.Connection, tenant_id: str, dataset_id: str, subject_id: str) -> int:
    row = conn.execute(
        'SELECT COALESCE(MAX(key_version), 0) AS max_version FROM subject_keys WHERE tenant_id = ? AND dataset_id = ? AND subject_id = ?',
        (tenant_id, dataset_id, subject_id),
    ).fetchone()
    return int(row['max_version']) + 1 if row else 1


def _get_active_subject_key(conn: sqlite3.Connection, tenant_id: str, dataset_id: str, subject_id: str) -> dict[str, Any] | None:
    row = conn.execute(
        """
        SELECT * FROM subject_keys
        WHERE tenant_id = ? AND dataset_id = ? AND subject_id = ? AND key_state = 'active'
        ORDER BY key_version DESC
        LIMIT 1
        """,
        (tenant_id, dataset_id, subject_id),
    ).fetchone()
    return _row_to_dict(row)


def _ensure_subject_key(conn: sqlite3.Connection, tenant_id: str, dataset_id: str, subject_id: str) -> tuple[dict[str, Any], bytes]:
    existing = _get_active_subject_key(conn, tenant_id, dataset_id, subject_id)
    if existing is not None:
        try:
            data_key = crypto.unwrap_key(existing['wrapped_key'], existing['wrapped_key_nonce'])
        except CryptoError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return existing, data_key

    version = _next_subject_key_version(conn, tenant_id, dataset_id, subject_id)
    data_key = crypto.generate_data_key()
    wrapped_key, wrapped_nonce = crypto.wrap_key(data_key)
    record = {
        'id': new_id('skey'),
        'tenant_id': tenant_id,
        'dataset_id': dataset_id,
        'subject_id': subject_id,
        'key_version': version,
        'wrapped_key': wrapped_key,
        'wrapped_key_nonce': wrapped_nonce,
        'key_state': 'active',
        'created_at': utc_now(),
        'destroyed_at': None,
    }
    conn.execute(
        """
        INSERT INTO subject_keys (id, tenant_id, dataset_id, subject_id, key_version, wrapped_key, wrapped_key_nonce, key_state, created_at, destroyed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            record['id'],
            record['tenant_id'],
            record['dataset_id'],
            record['subject_id'],
            record['key_version'],
            record['wrapped_key'],
            record['wrapped_key_nonce'],
            record['key_state'],
            record['created_at'],
            record['destroyed_at'],
        ),
    )
    _audit(
        conn,
        'subject_key',
        record['id'],
        'subject_key.created',
        {
            'tenant_id': tenant_id,
            'dataset_id': dataset_id,
            'subject_id': subject_id,
            'key_version': version,
        },
    )
    return record, data_key


def create_record(payload: RecordCreate) -> dict[str, Any]:
    with get_conn() as conn:
        _fetch_tenant(conn, payload.tenant_id)
        dataset = _fetch_dataset(conn, payload.dataset_id)
        if dataset['tenant_id'] != payload.tenant_id:
            raise HTTPException(status_code=400, detail='Dataset does not belong to tenant.')

        subject_key, data_key = _ensure_subject_key(conn, payload.tenant_id, payload.dataset_id, payload.subject_id)
        record_id = new_id('rec')
        aad = {
            'tenant_id': payload.tenant_id,
            'dataset_id': payload.dataset_id,
            'subject_id': payload.subject_id,
            'record_type': payload.record_type,
            'subject_key_id': subject_key['id'],
            'record_id': record_id,
            'schema': 'erasekey.record.v1',
        }
        ciphertext, nonce = crypto.encrypt_payload(data_key, payload.payload, aad)
        record = {
            'id': record_id,
            'tenant_id': payload.tenant_id,
            'dataset_id': payload.dataset_id,
            'subject_id': payload.subject_id,
            'subject_key_id': subject_key['id'],
            'record_type': payload.record_type,
            'ciphertext': ciphertext,
            'nonce': nonce,
            'aad': canonical_json(aad),
            'created_at': utc_now(),
        }
        conn.execute(
            """
            INSERT INTO records (id, tenant_id, dataset_id, subject_id, subject_key_id, record_type, ciphertext, nonce, aad, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record['id'],
                record['tenant_id'],
                record['dataset_id'],
                record['subject_id'],
                record['subject_key_id'],
                record['record_type'],
                record['ciphertext'],
                record['nonce'],
                record['aad'],
                record['created_at'],
            ),
        )
        _audit(
            conn,
            'record',
            record['id'],
            'record.ingested',
            {
                'tenant_id': record['tenant_id'],
                'dataset_id': record['dataset_id'],
                'subject_id': record['subject_id'],
                'subject_key_id': record['subject_key_id'],
                'record_type': record['record_type'],
            },
        )
        return {
            'id': record['id'],
            'tenant_id': record['tenant_id'],
            'dataset_id': record['dataset_id'],
            'subject_id': record['subject_id'],
            'record_type': record['record_type'],
            'created_at': record['created_at'],
            'payload': payload.payload,
            'key_state': 'active',
            'erase_status': 'readable',
        }


def read_record(record_id: str) -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM records WHERE id = ?', (record_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail='Record not found.')
        record = _row_to_dict(row) or {}
        key_row = conn.execute('SELECT * FROM subject_keys WHERE id = ?', (record['subject_key_id'],)).fetchone()
        if key_row is None:
            return {
                'id': record['id'],
                'tenant_id': record['tenant_id'],
                'dataset_id': record['dataset_id'],
                'subject_id': record['subject_id'],
                'record_type': record['record_type'],
                'created_at': record['created_at'],
                'payload': None,
                'key_state': 'missing',
                'erase_status': 'cryptographically_erased',
            }
        key_item = _row_to_dict(key_row) or {}
        if key_item['key_state'] != 'active' or not key_item['wrapped_key'] or not key_item['wrapped_key_nonce']:
            return {
                'id': record['id'],
                'tenant_id': record['tenant_id'],
                'dataset_id': record['dataset_id'],
                'subject_id': record['subject_id'],
                'record_type': record['record_type'],
                'created_at': record['created_at'],
                'payload': None,
                'key_state': key_item['key_state'],
                'erase_status': 'cryptographically_erased',
            }
        try:
            data_key = crypto.unwrap_key(key_item['wrapped_key'], key_item['wrapped_key_nonce'])
            payload = crypto.decrypt_payload(
                data_key=data_key,
                ciphertext=record['ciphertext'],
                nonce=record['nonce'],
                aad=json.loads(record['aad']),
            )
        except CryptoError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return {
            'id': record['id'],
            'tenant_id': record['tenant_id'],
            'dataset_id': record['dataset_id'],
            'subject_id': record['subject_id'],
            'record_type': record['record_type'],
            'created_at': record['created_at'],
            'payload': payload,
            'key_state': key_item['key_state'],
            'erase_status': 'readable',
        }


def create_deletion_request(payload: DeletionRequestCreate) -> dict[str, Any]:
    with get_conn() as conn:
        _fetch_tenant(conn, payload.tenant_id)
        dataset = _fetch_dataset(conn, payload.dataset_id)
        if dataset['tenant_id'] != payload.tenant_id:
            raise HTTPException(status_code=400, detail='Dataset does not belong to tenant.')

        holds = _find_active_holds(conn, payload.tenant_id, payload.dataset_id, payload.subject_id)
        blocked_reason = None
        status_value = 'pending'
        if holds:
            status_value = 'blocked'
            blocked_reason = f'Active legal hold count: {len(holds)}'

        base_request = {
            'tenant_id': payload.tenant_id,
            'dataset_id': payload.dataset_id,
            'subject_id': payload.subject_id,
            'requested_by': payload.requested_by.strip(),
            'reason': payload.reason.strip(),
        }
        request_hash = sha256_hex(base_request)
        record = {
            'id': new_id('delreq'),
            **base_request,
            'status': status_value,
            'blocked_reason': blocked_reason,
            'created_at': utc_now(),
            'executed_at': None,
            'request_hash': request_hash,
        }
        conn.execute(
            """
            INSERT INTO deletion_requests (id, tenant_id, dataset_id, subject_id, requested_by, reason, status, blocked_reason, created_at, executed_at, evidence_json, request_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record['id'],
                record['tenant_id'],
                record['dataset_id'],
                record['subject_id'],
                record['requested_by'],
                record['reason'],
                record['status'],
                record['blocked_reason'],
                record['created_at'],
                None,
                None,
                record['request_hash'],
            ),
        )
        _audit(conn, 'deletion_request', record['id'], 'deletion_request.created', record)
        return record


def get_deletion_request(request_id: str) -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM deletion_requests WHERE id = ?', (request_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail='Deletion request not found.')
        return _row_to_dict(row) or {}


def execute_deletion_request(request_id: str) -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('SELECT * FROM deletion_requests WHERE id = ?', (request_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail='Deletion request not found.')
        request_item = _row_to_dict(row) or {}

        if request_item['status'] == 'executed':
            return request_item

        holds = _find_active_holds(
            conn,
            request_item['tenant_id'],
            request_item['dataset_id'],
            request_item['subject_id'],
        )
        if holds:
            blocked_reason = f'Active legal hold count: {len(holds)}'
            conn.execute(
                'UPDATE deletion_requests SET status = ?, blocked_reason = ? WHERE id = ?',
                ('blocked', blocked_reason, request_id),
            )
            request_item['status'] = 'blocked'
            request_item['blocked_reason'] = blocked_reason
            _audit(
                conn,
                'deletion_request',
                request_id,
                'deletion_request.blocked',
                {'blocked_reason': blocked_reason},
            )
            return request_item

        active_keys = conn.execute(
            """
            SELECT * FROM subject_keys
            WHERE tenant_id = ? AND dataset_id = ? AND subject_id = ? AND key_state = 'active'
            ORDER BY key_version DESC
            """,
            (request_item['tenant_id'], request_item['dataset_id'], request_item['subject_id']),
        ).fetchall()
        destroyed_key_ids: list[str] = []
        destroyed_at = utc_now()
        for key_row in active_keys:
            key_item = _row_to_dict(key_row) or {}
            conn.execute(
                """
                UPDATE subject_keys
                SET wrapped_key = NULL,
                    wrapped_key_nonce = NULL,
                    key_state = 'destroyed',
                    destroyed_at = ?
                WHERE id = ?
                """,
                (destroyed_at, key_item['id']),
            )
            destroyed_key_ids.append(key_item['id'])
            _audit(
                conn,
                'subject_key',
                key_item['id'],
                'subject_key.destroyed',
                {
                    'destroyed_at': destroyed_at,
                    'reason': f'Cryptographic erasure via deletion request {request_id}',
                },
            )

        record_count_row = conn.execute(
            'SELECT COUNT(*) AS count FROM records WHERE tenant_id = ? AND dataset_id = ? AND subject_id = ?',
            (request_item['tenant_id'], request_item['dataset_id'], request_item['subject_id']),
        ).fetchone()
        record_count = int(record_count_row['count']) if record_count_row else 0
        sample_row = conn.execute(
            'SELECT id FROM records WHERE tenant_id = ? AND dataset_id = ? AND subject_id = ? ORDER BY created_at DESC LIMIT 1',
            (request_item['tenant_id'], request_item['dataset_id'], request_item['subject_id']),
        ).fetchone()
        sample_record_id = sample_row['id'] if sample_row else None

        evidence = {
            'executed_at': destroyed_at,
            'tenant_id': request_item['tenant_id'],
            'dataset_id': request_item['dataset_id'],
            'subject_id': request_item['subject_id'],
            'record_count': record_count,
            'destroyed_key_ids': destroyed_key_ids,
            'verification': {
                'sample_record_id': sample_record_id,
                'result': 'unreadable' if sample_record_id else 'no_records_found',
                'reason': 'Subject data keys were destroyed; ciphertext may remain but is no longer decryptable.',
            },
            'controls': {
                'live_data_action': 'application keeps ciphertext to model backup/cold-storage reality in MVP',
                'crypto_action': 'wrapped subject keys destroyed',
                'legal_hold_checked': True,
            },
            'request_hash': request_item['request_hash'],
        }

        conn.execute(
            'UPDATE deletion_requests SET status = ?, blocked_reason = NULL, executed_at = ?, evidence_json = ? WHERE id = ?',
            ('executed', destroyed_at, canonical_json(evidence), request_id),
        )
        request_item['status'] = 'executed'
        request_item['blocked_reason'] = None
        request_item['executed_at'] = destroyed_at
        _audit(
            conn,
            'deletion_request',
            request_id,
            'deletion_request.executed',
            evidence,
        )
        return request_item


def get_evidence(request_id: str) -> dict[str, Any]:
    with get_conn() as conn:
        row = conn.execute('SELECT id, status, evidence_json FROM deletion_requests WHERE id = ?', (request_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail='Deletion request not found.')
        if row['evidence_json'] is None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail='Deletion request has no evidence yet. Execute it first.',
            )
        return {
            'request_id': row['id'],
            'status': row['status'],
            'evidence': json.loads(row['evidence_json']),
        }


def list_audit_events(entity_type: str | None = None, entity_id: str | None = None) -> list[dict[str, Any]]:
    with get_conn() as conn:
        sql = 'SELECT * FROM audit_events'
        params: list[Any] = []
        clauses: list[str] = []
        if entity_type:
            clauses.append('entity_type = ?')
            params.append(entity_type)
        if entity_id:
            clauses.append('entity_id = ?')
            params.append(entity_id)
        if clauses:
            sql += ' WHERE ' + ' AND '.join(clauses)
        sql += ' ORDER BY created_at DESC LIMIT 200'
        rows = conn.execute(sql, params).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            item = _row_to_dict(row) or {}
            item['payload_json'] = json.loads(item['payload_json'])
            results.append(item)
        return results
